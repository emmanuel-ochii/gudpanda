<template>
  <div>
    <div>{{ title }}</div>
  </div>
</template>


<script setup>

defineProps({ title: String });
</script>

// <script>
// import FrontendLayout from "../../Layouts/FrontendLayout.vue";
// export default {
//     layout: FrontendLayout
// }
//
</script>
