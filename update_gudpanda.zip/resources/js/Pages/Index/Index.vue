<template>
  <div>
    <div>{{title }}</div>
  </div>
</template>


<script setup>

defineProps({title: String})
</script>

